<?
    header("Content-Type: application/x-web-app-manifest+json");
?>{  
  "version": "1.0",
  "name": "Wikipedia",
  "description": "",
  "icons": {
    "60": "http://doatresizer.appspot.com/?width=60&height=60&url=https://admin.prod.doit9.com/img/app/26&overlay=round"
  },
  "developer": {
    "name": "Wikipedia",
    "url": "http://wikipedia.org"
  }
}