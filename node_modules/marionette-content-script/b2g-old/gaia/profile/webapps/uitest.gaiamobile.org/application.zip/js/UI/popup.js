document.getElementById('close').onclick = function() {
  window.close();
};
