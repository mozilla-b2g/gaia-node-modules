# JSZhuyin in Firefox OS Keyboard app

The JSZhuyin library is not developed in this repository.
The code come from:

https://github.com/timdream/jszhuyin

To update the code here, run `pull.sh` to pull the files and data.
You would need to generate the data from McBopomofo first.
