'use strict';

var MockContactsExporter = function() {
  return {
    'init': function(ids, cb) {},
    'setExportStrategy': function(st) {},
    'start': function() {}
  };
}();
