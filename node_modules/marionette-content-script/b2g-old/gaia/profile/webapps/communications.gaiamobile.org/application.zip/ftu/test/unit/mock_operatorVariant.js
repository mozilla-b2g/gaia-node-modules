'use strict';

var MockOperatorVariant = {
  setSIMOnFirstBootState: function() {}
};
