var MockNavigation = {
  'go': function(view, transition) {},
  'back': function(cb) {}
};
