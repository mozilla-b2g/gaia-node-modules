'use strict';

var MockSwiper = {
  setElasticEnabled: function() {}
};
