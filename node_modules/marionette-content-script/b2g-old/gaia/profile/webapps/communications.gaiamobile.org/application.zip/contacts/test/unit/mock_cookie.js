'use strict';

var MockCookie = {
  data: {},
  update: function(obj) {
    this.data = obj;
  }
};
