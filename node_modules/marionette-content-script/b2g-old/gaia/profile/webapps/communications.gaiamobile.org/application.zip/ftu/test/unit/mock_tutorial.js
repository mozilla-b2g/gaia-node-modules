'use strict';

var MockTutorial = {
  init: function() {}
};
