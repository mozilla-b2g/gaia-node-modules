'use strict';

var MockImportIntegration = {
  checkImport: function() {}
};
